$(function(){
console.log("Hello!")
});